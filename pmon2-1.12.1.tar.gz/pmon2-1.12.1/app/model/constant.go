package model

const (
	CmdStart   = "start"
	CmdStop    = "stop"
	CmdReload  = "reload"
	CmdList    = "list"
	CmdMonitor = "monitor"
)
